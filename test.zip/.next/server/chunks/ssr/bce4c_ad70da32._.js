module.exports = [
"[project]/test/nextjs-project/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
exports._ = _interop_require_default;
}),
"[project]/test/nextjs-project/node_modules/next/dist/client/components/builtin/layout.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return DefaultLayout;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/test/nextjs-project/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-rsc] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/test/nextjs-project/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-runtime.js [app-rsc] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/test/nextjs-project/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)"));
function DefaultLayout(param) {
    let { children } = param;
    return /*#__PURE__*/ (0, _jsxruntime.jsx)("html", {
        children: /*#__PURE__*/ (0, _jsxruntime.jsx)("body", {
            children: children
        })
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=layout.js.map
}),
];

//# sourceMappingURL=bce4c_ad70da32._.js.map