globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/bce4c_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2a9b325b._.js",
    "static/chunks/bce4c_next_dist_compiled_react-dom_e5f75cc6._.js",
    "static/chunks/bce4c_next_dist_compiled_next-devtools_index_26b6ad82.js",
    "static/chunks/bce4c_next_dist_compiled_542ae8fb._.js",
    "static/chunks/bce4c_next_dist_client_d7392cef._.js",
    "static/chunks/bce4c_next_dist_b52676d6._.js",
    "static/chunks/bce4c_@swc_helpers_cjs_49e7badd._.js",
    "static/chunks/test_nextjs-project_a0ff3932._.js",
    "static/chunks/turbopack-test_nextjs-project_ba78d555._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];