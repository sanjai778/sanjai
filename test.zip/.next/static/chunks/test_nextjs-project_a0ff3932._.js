(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2a9b325b._.js",
  "static/chunks/bce4c_next_dist_compiled_react-dom_e5f75cc6._.js",
  "static/chunks/bce4c_next_dist_compiled_next-devtools_index_26b6ad82.js",
  "static/chunks/bce4c_next_dist_compiled_542ae8fb._.js",
  "static/chunks/bce4c_next_dist_client_d7392cef._.js",
  "static/chunks/bce4c_next_dist_b52676d6._.js",
  "static/chunks/bce4c_@swc_helpers_cjs_49e7badd._.js"
],
    source: "entry"
});
