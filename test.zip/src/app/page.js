// The "export default" is critical.
export default function HomePage() {
  return (
    <div>
      <h1>Welcome to my Next.js App!</h1>
      <p>This page is now working.</p>
    </div>
  );
}